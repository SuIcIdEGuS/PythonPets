create_table_categ = "CREATE TABLE `Category` (id int AUTO_INCREMENT," \
                     " name varchar(32)," \
                     " description varchar(32)," \
                     " PRIMARY KEY (id));"

create_table_pets = "CREATE TABLE `Pets` (id int AUTO_INCREMENT," \
                     " nickname varchar(32)," \
                     " age int," \
                     " gender varchar(32)," \
                     " breed varchar(32)," \
                     " price decimal(10, 2)," \
                     " img blob," \
                     " description varchar(32)," \
                     " category_id INT,"\
                     " PRIMARY KEY (id),"\
                     " FOREIGN KEY (category_id) REFERENCES Category(id));"

create_table_custom = "CREATE TABLE `Customer` (id int AUTO_INCREMENT," \
                    " first_name varchar(32)," \
                    " last_name varchar(32)," \
                    " email varchar(32)," \
                    " phone varchar(32)," \
                    " passport varchar(32)," \
                    " login varchar(32)," \
                    " password varchar(32)," \
                    " PRIMARY KEY (id));"

create_table_basket = "CREATE TABLE `Basket` (id int AUTO_INCREMENT," \
                     " customer_id INT," \
                     " pet_id INT," \
                     " quantity int," \
                     " PRIMARY KEY (id),"\
                     " FOREIGN KEY (customer_id) REFERENCES Customer(id),"\
                     " FOREIGN KEY (pet_id) REFERENCES Pets(id));"

create_table_cheque = "CREATE TABLE `Cheque` (id int AUTO_INCREMENT," \
                     " date DATE," \
                     " payment_type VARCHAR(32)," \
                     " customer_id INT," \
                     " PRIMARY KEY (id),"\
                     " FOREIGN KEY (customer_id) REFERENCES Customer(id));"

create_table_sales = "CREATE TABLE `Sales` (id int AUTO_INCREMENT," \
                     " check_id int," \
                     " basket_id int," \
                     " quantity int," \
                     " PRIMARY KEY (id),"\
                     " FOREIGN KEY (check_id) REFERENCES Cheque(id),"\
                     " FOREIGN KEY (basket_id) REFERENCES Basket(id));"\

insert_category = "INSERT INTO `Category` (name, description) VALUES ('Собака', 'Бульдог'),('Кошка', 'Сибирскя'),('Птица', 'Жако');"

insert_pets = "INSERT INTO pets (nickname, age, gender, breed, price, img, description, category_id) VALUES ('Бодди', 3, 'Мужской', 'Сибирская', 500.00, NULL, 'Лучший друг ', 1), ('Флиффу', 2, 'Женский', 'Будьдог', 300.00, NULL, 'Заботливая', 2),('Твитти', 1, 'Женский', 'Красный', 50.00, NULL, 'Любит ласку', 3);"\

insert_Customer  = "INSERT INTO Customer  (first_name, last_name, email, phone, passport, login, password) VALUES ('Шамиль', 'Алиев', 'johndoe@example.com', '555-1234', '123456789', 'johndoe', 'password123'),('Генри', 'Кавилл', 'janesmith@example.com', '555-5678', '987654321', 'janesmith', 'password456');"\

insert_Basket = "INSERT INTO Basket  (customer_id, pet_id, quantity) VALUES (1, 1, 2), (1, 2, 1), (2, 3, 3);"
insert_Cheque  = "INSERT INTO Cheque  (date, payment_type, customer_id) VALUES ('2023-05-15', 'Кредитной картой', 1), ('2023-05-16', 'Наличными', 2);"
insert_Sales = "INSERT INTO Sales (check_id, basket_id, quantity) VALUES (1, 1, 2), (1, 2, 1), (2, 3, 3);"

viewPetCategory = "CREATE VIEW PetsByCategory AS select Category.name, Pets.nickname, Pets.gender, Pets.age, Pets.price FROM Category INNER JOIN Pets ON Category.id=Pets.category_id "
viewCheck = "CREATE VIEW ViewCheckPokup AS SELECT Cheque.id as cheque_id, Cheque.date, Cheque.payment_type, Customer.first_name, Customer.last_name, Customer.email, Customer.phone FROM Cheque INNER JOIN Customer ON Cheque.customer_id = Customer.id"
viewMostExp = "Create View  MostExp  as select nickname, breed, MAX(price) as pets From Pets GROUP BY nickname, breed LIMIT 1"
viewMostCat = "Create View  mostCat as select  MAX(name) as most_pets From Category"







